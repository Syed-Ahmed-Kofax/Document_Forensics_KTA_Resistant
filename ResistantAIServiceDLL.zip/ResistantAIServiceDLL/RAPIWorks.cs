﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

namespace ResistantAIServiceDLL
{
    [DataContract]
    class S3Details
    {
        [DataMember]
        public string upload_url { get; set; }

        [DataMember]
        public string submission_id { get; set; }
    }

    [DataContract]
    class ResultResponseClass
    {
        [DataMember]
        public string score { get; set; }

        [DataMember]
        public string risk { get; set; }
        [DataMember]
        public string trust { get; set; }

        [DataMember]
        public string query_id { get; set; }
        [DataMember]
        public string file_type { get; set; }
    }
    public class RAPIWorks
    {
        private String[] GetS3UploadURL(String URL, String DocName, String AuthCode)
        {
            //Cleaning the fileName
            DocName = Regex.Replace(DocName, @"[^0-9a-zA-Z]+", "");
            //Setting the URi and calling the get document API
            var KTAGetDocumentFile = URL;
            HttpWebRequest ktaHttpWebRequest = (HttpWebRequest)WebRequest.Create(KTAGetDocumentFile);
            ktaHttpWebRequest.ContentType = "application/json";
            ktaHttpWebRequest.Headers.Add(HttpRequestHeader.Authorization, AuthCode);
            ktaHttpWebRequest.Method = "POST";

            // CONSTRUCT JSON Payload
            using (var streamWriter = new StreamWriter(ktaHttpWebRequest.GetRequestStream()))
            {
                string json = "";
                streamWriter.Write(json);
                streamWriter.Flush();
            }
            //Reading response from API
            String responseText = String.Empty;
            S3Details bsObj2;
            HttpWebResponse ktaHttpWebResponse = (HttpWebResponse)ktaHttpWebRequest.GetResponse();
            var encoding = ASCIIEncoding.UTF8;
            using (var reader = new System.IO.StreamReader(ktaHttpWebResponse.GetResponseStream(), encoding))
            {
                responseText = reader.ReadToEnd();
            }
            //deserialize JSON string to its key value pairs
            using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(responseText)))
            {
                // Deserialization from JSON
                DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(S3Details));
                bsObj2 = (S3Details)deserializer.ReadObject(ms);
            }
            String[] ReturnParamteres = { bsObj2.upload_url, bsObj2.submission_id };
            return ReturnParamteres;
        }
        public String[] UploadFiles(String URL, String DocName, String AuthCode, String Base64)
        {

            String SubmissionID = string.Empty;
            String GUUUploadURL = String.Empty;
            try
            {
                byte[] FileArray = Convert.FromBase64String(Base64);
                String[] GUUResult = GetS3UploadURL(URL, DocName, AuthCode);
                GUUUploadURL = GUUResult.GetValue(0).ToString();
                SubmissionID = GUUResult.GetValue(1).ToString();

                var KTAGetDocumentFile = GUUUploadURL;
                HttpWebRequest ktaHttpWebRequest = (HttpWebRequest)WebRequest.Create(KTAGetDocumentFile);
                ktaHttpWebRequest.ContentType = "application/octet-stream";
                ktaHttpWebRequest.ContentLength = FileArray.Length;
                //ktaHttpWebRequest.Headers.Add(HttpRequestHeader.Authorization, AuthCode);
                ktaHttpWebRequest.Method = "PUT";

                // CONSTRUCT JSON Payload
                using (var streamWriter = new StreamWriter(ktaHttpWebRequest.GetRequestStream()))
                {
                    streamWriter.BaseStream.Write(FileArray, 0, FileArray.Length);
                    streamWriter.Flush();
                }

                //Reading response from API
                String responseText = String.Empty;
                HttpWebResponse ktaHttpWebResponse = (HttpWebResponse)ktaHttpWebRequest.GetResponse();
                var encoding = ASCIIEncoding.UTF8;
                using (var reader = new System.IO.StreamReader(ktaHttpWebResponse.GetResponseStream(), encoding))
                {
                    responseText = reader.ReadToEnd();
                }
                string[] Returnarray = { ktaHttpWebResponse.StatusCode.ToString(), ktaHttpWebResponse.StatusDescription.ToString(), SubmissionID };
                return Returnarray;
            }
            catch (Exception e)
            {
                string[] arrayError = { "ERROR", e.Message.ToString(), SubmissionID };
                return arrayError;
            }
        }
        public String[] GetResult(String SubmissionID, String URL, String AuthCode)
        {
            string[] arrayError = new string[] { "", "", "", "", "", "" };

            try
            {
                var KTAGetDocumentFile = string.Concat(URL, SubmissionID);
                //create header
                HttpWebRequest ktaHttpWebRequest = (HttpWebRequest)WebRequest.Create(KTAGetDocumentFile);
                ktaHttpWebRequest.ContentType = "application/json";
                ktaHttpWebRequest.Headers.Add(HttpRequestHeader.Authorization, AuthCode);
                ktaHttpWebRequest.Method = "GET";
                //getresponse
                String responseText = String.Empty;
                ResultResponseClass RSObj;
                HttpWebResponse ktaHttpWebResponse = (HttpWebResponse)ktaHttpWebRequest.GetResponse();
                var encoding = ASCIIEncoding.UTF8;
                using (var reader = new System.IO.StreamReader(ktaHttpWebResponse.GetResponseStream(), encoding))
                {
                    responseText = reader.ReadToEnd();
                }
                //deserialize JSON string to its key value pairs
                using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(responseText)))
                {
                    // Deserialization from JSON
                    DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(ResultResponseClass));
                    RSObj = (ResultResponseClass)deserializer.ReadObject(ms);

                }
                //return the response to KTA
                if (ktaHttpWebResponse.StatusCode.ToString() == "OK")
                {
                    arrayError[0] = ktaHttpWebResponse.StatusCode.ToString();
                    arrayError[1] = Convert.ToString(RSObj.score);
                    arrayError[2] = Convert.ToString(RSObj.risk);
                    arrayError[3] = Convert.ToString(RSObj.trust);
                    arrayError[4] = Convert.ToString(RSObj.query_id);
                    arrayError[5] = Convert.ToString(RSObj.file_type);
                }
                else
                {
                    arrayError[0] = ktaHttpWebResponse.StatusCode.ToString();
                    arrayError[1] = "ERROR";
                    arrayError[2] = "ERROR";
                    arrayError[3] = "ERROR";
                    arrayError[4] = "ERROR";
                    arrayError[5] = "ERROR";
                }


                return arrayError;
            }
            catch (Exception e)
            {
                arrayError[0] = e.Message.ToString();
                return arrayError;
            }
        }
    }
}
